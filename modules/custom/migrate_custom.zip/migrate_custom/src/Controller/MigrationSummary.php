<?php

namespace Drupal\migrate_custom\Controller;

use Drupal\Core\Controller\ControllerBase;

class MigrationSummary extends ControllerBase {
  public function generateReport() {
    // Switch to external database
    $db = \Drupal\Core\Database\Database::setActiveConnection('migrate');
    // Get a connection going
    $db = \Drupal\Core\Database\Database::getConnection();

    // Node types
    $node_types = $db->select('node_type','n')
      ->fields('n', array('name'))
      ->execute()
      ->fetchAll();

    $nodetypes = count($node_types);
    $data['Content_types'] = $nodetypes;

    //No of nodes
    $nodes_count = $db->select('node','n')
      ->fields('n', array('nid'))
      ->execute()
      ->fetchAll();

    $nodes = count($nodes_count);
    $data['nodes'] = $nodes;

    $files = $db->select('file_managed', 'f')
      ->fields('f', array('fid'))
      ->execute()
      ->fetchAll();
    $files_managed = count($files);

    $data['files_managed'] = $files_managed;

    //Fetching userroles
    $userroles = $db->select('role', 'r')
      ->fields('r', array('name'))
      ->execute()
      ->fetchAll();

    $roles = count($userroles);
    $data['roles'] = $roles;

    //Fetching users
    $usersquery = $db->select('users', 'u')
      ->fields('u', array('uid'))
      ->execute()
      ->fetchAll();

    $users = count($usersquery);
    $data['users'] = $users;

    //Fetching taxonomy vocabulary
    $taxonomy_vocab = $db->select('taxonomy_vocabulary', 't')
      ->fields('t', array('name'))
      ->execute()
      ->fetchAll();

    $taxonomy_vocabulary = count($taxonomy_vocab);
    $data['taxonomy_vocabulary'] = $taxonomy_vocabulary;

    //Fetching taxonomy terms
    $taxonomy_terms = $db->select('taxonomy_term_data', 't')
      ->fields('t', array('tid'))
      ->execute()
      ->fetchAll();

    $terms = count($taxonomy_terms);
    $data['terms'] = $terms;

    //Adding viewsdata
    $viewsdata = array();
    //if ( \Drupal\Core\Extension\ModuleHandler::moduleExists('views')) {
      //Fetching views data
      $query = $db->select('views_view', 'v')
        ->fields('v', array('vid', 'name', 'description'))
        ->execute();

      foreach ($query as $view) {

        $query2 = $db->select('views_display', 'v')
          ->fields('v', array('id', 'display_title'))
          ->condition('vid', $view->vid, '=')
          ->execute()
          ->fetchAll();

        $display_count = count($query2);
        array_push($viewsdata, array('view' => $view->name, 'description' => $view->description, 'displays' => $display_count));
      }
    //}
    $data['viewsdata'] = $viewsdata;

    //Fetch Data of all enabled Modules
    $enabled_modules = $db->select('system', 's')
      ->fields('s', array('filename', 'name', 'schema_version'))
      ->condition('status', 1, '=')
      ->condition('type', 'module', '=')
      ->execute()
      ->fetchAll();
    $enabled_modules = count($enabled_modules);
    $data['enabled_modules'] = $enabled_modules;

    //Fetch Data of all enabled Themes
    $enabled_themes = $db->select('system', 's')
      ->fields('s', array('filename', 'name', 'schema_version'))
      ->condition('status', 1, '=')
      ->condition('type', 'theme', '=')
      ->execute()
      ->fetchAll();
    $enabled_themes = count($enabled_themes);
    $data['enabled_themes'] = $enabled_themes;

    $response = [
      '#markup' => $this->t('Hello World!'),
    ];
    print "<pre>";
    print_r($data);
    exit;
    return $data;
  }

}
